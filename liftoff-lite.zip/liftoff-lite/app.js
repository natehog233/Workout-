// Intentionally empty; logic is embedded in index.html for a single-file deploy.
